//+------------------------------------------------------------------+
//|                                       Scikit.Regression.ONNX.mq5 |
//|                                  Copyright 2023, MetaQuotes Ltd. |
//|                                             https://www.mql5.com |
//+------------------------------------------------------------------+
#define   TestFloatModel  1
#define   TestDoubleModel 2
//---
#resource "models\\ard_regression_float.onnx" as const uchar ExtModelARDRegressionF[];
#resource "models\\ard_regression_double.onnx" as const uchar ExtModelARDRegressionD[];
#resource "models\\bayesian_ridge_float.onnx" as const uchar ExtModelBayesianRidgeF[];
#resource "models\\bayesian_ridge_double.onnx" as const uchar ExtModelBayesianRidgeD[];
#resource "models\\elastic_net_float.onnx" as const uchar ExtModelElasticNetF[];
#resource "models\\elastic_net_double.onnx" as const uchar ExtModelElasticNetD[];
#resource "models\\elastic_net_cv_float.onnx" as const uchar ExtModelElasticNetCVF[];
#resource "models\\elastic_net_cv_double.onnx" as const uchar ExtModelElasticNetCVD[];
#resource "models\\huber_regressor_float.onnx" as const uchar ExtModelHuberRegressorF[];
#resource "models\\huber_regressor_double.onnx" as const uchar ExtModelHuberRegressorD[];
#resource "models\\lars_float.onnx" as const uchar ExtModelLarsF[];
#resource "models\\lars_double.onnx" as const uchar ExtModelLarsD[];
#resource "models\\lars_cv_float.onnx" as const uchar ExtModelLarsCVF[];
#resource "models\\lars_cv_double.onnx" as const uchar ExtModelLarsCVD[];
#resource "models\\lasso_float.onnx" as const uchar ExtModelLassoF[];
#resource "models\\lasso_double.onnx" as const uchar ExtModelLassoD[];
#resource "models\\lasso_cv_float.onnx" as const uchar ExtModelLassoCVF[];
#resource "models\\lasso_cv_double.onnx" as const uchar ExtModelLassoCVD[];
#resource "models\\lasso_lars_float.onnx" as const uchar ExtModelLassoLarsF[];
#resource "models\\lasso_lars_double.onnx" as const uchar ExtModelLassoLarsD[];
#resource "models\\lasso_lars_cv_float.onnx" as const uchar ExtModelLassoLarsCVF[];
#resource "models\\lasso_lars_cv_double.onnx" as const uchar ExtModelLassoLarsCVD[];
#resource "models\\lasso_lars_ic_float.onnx" as const uchar ExtModelLassoLarsICF[];
#resource "models\\lasso_lars_ic_double.onnx" as const uchar ExtModelLassoLarsICD[];
#resource "models\\linear_regression_float.onnx" as const uchar ExtModelLinearRegressionF[];
#resource "models\\linear_regression_double.onnx" as const uchar ExtModelLinearRegressionD[];
#resource "models\\ridge_float.onnx" as const uchar ExtModelRidgeF[];
#resource "models\\ridge_double.onnx" as const uchar ExtModelRidgeD[];
#resource "models\\ridge_cv_float.onnx" as const uchar ExtModelRidgeCVF[];
#resource "models\\ridge_cv_double.onnx" as const uchar ExtModelRidgeCVD[];
#resource "models\\orthogonal_matching_pursuit_float.onnx" as const uchar ExtModelOMPF[];
#resource "models\\orthogonal_matching_pursuit_double.onnx" as const uchar ExtModelOMPD[];
#resource "models\\passive_aggressive_regressor_float.onnx" as const uchar ExtModelPAD[];
#resource "models\\passive_aggressive_regressor_double.onnx" as const uchar ExtModelPAF[];
#resource "models\\quantile_regressor_float.onnx" as const uchar ExtModelQuantileRegressorF[];
#resource "models\\quantile_regressor_double.onnx" as const uchar ExtModelQuantileRegressorD[];
#resource "models\\ransac_regressor_float.onnx" as const uchar ExtModelRANSACRegressorF[];
#resource "models\\ransac_regressor_double.onnx" as const uchar ExtModelRANSACRegressorD[];
#resource "models\\theil_sen_regressor_double.onnx" as const uchar ExtModelTheilSenRegressorD[];
#resource "models\\theil_sen_regressor_float.onnx" as const uchar ExtModelTheilSenRegressorF[];
#resource "models\\linear_svr_float.onnx" as const uchar ExtModelLinearSVRF[];
#resource "models\\linear_svr_double.onnx" as const uchar ExtModelLinearSVRD[];
#resource "models\\mlp_regressor_float.onnx" as const uchar ExtModelMLPRegressorF[];
#resource "models\\mlp_regressor_double.onnx" as const uchar ExtModelMLPRegressorD[];
#resource "models\\pls_regression_float.onnx" as const uchar ExtModelPLSRegressionF[];
#resource "models\\pls_regression_double.onnx" as const uchar ExtModelPLSRegressionD[];
#resource "models\\tweedie_regressor_float.onnx" as const uchar ExtModelTweedieRegressorF[];
#resource "models\\tweedie_regressor_double.onnx" as const uchar ExtModelTweedieRegressorD[];
#resource "models\\poisson_regressor_float.onnx" as const uchar ExtModelPoissonRegressorF[];
#resource "models\\poisson_regressor_double.onnx" as const uchar ExtModelPoissonRegressorD[];
#resource "models\\radius_neighbors_regressor_float.onnx" as const uchar ExtModelRadiusNeighborsRegressorF[];
#resource "models\\radius_neighbors_regressor_double.onnx" as const uchar ExtModelRadiusNeighborsRegressorD[];
#resource "models\\kneighbors_regressor_float.onnx" as const uchar ExtModelKNeighborsRegressorF[];
#resource "models\\kneighbors_regressor_double.onnx" as const uchar ExtModelKNeighborsRegressorD[];
#resource "models\\gaussian_process_regressor_float.onnx" as const uchar ExtModelGaussianProcessRegressorF[];
#resource "models\\gaussian_process_regressor_double.onnx" as const uchar ExtModelGaussianProcessRegressorD[];
#resource "models\\gamma_regressor_float.onnx" as const uchar ExtModelGammaRegressorF[];
#resource "models\\gamma_regressor_double.onnx" as const uchar ExtModelGammaRegressorD[];
#resource "models\\sgd_regressor_double.onnx" as const uchar ExtModelSGDRegressorD[];
#resource "models\\sgd_regressor_float.onnx" as const uchar ExtModelSGDRegressorF[];
#resource "models\\adaboost_regressor_float.onnx" as const uchar ExtModelAdaBoostRegressorF[];
#resource "models\\adaboost_regressor_double.onnx" as const uchar ExtModelAdaBoostRegressorD[];
#resource "models\\bagging_regressor_float.onnx" as const uchar ExtModelBaggingRegressorF[];
#resource "models\\bagging_regressor_double.onnx" as const uchar ExtModelBaggingRegressorD[];
#resource "models\\decision_tree_regressor_float.onnx" as const uchar ExtModelDecisionTreeRegressorF[];
#resource "models\\decision_tree_regressor_double.onnx" as const uchar ExtModelDecisionTreeRegressorD[];
#resource "models\\extra_tree_regressor_float.onnx" as const uchar ExtModelExtraTreeRegressorF[];
#resource "models\\extra_tree_regressor_double.onnx" as const uchar ExtModelExtraTreeRegressorD[];
#resource "models\\extra_trees_regressor_float.onnx" as const uchar ExtModelExtraTreesRegressorF[];
#resource "models\\extra_trees_regressor_double.onnx" as const uchar ExtModelExtraTreesRegressorD[];
#resource "models\\nu_svr_float.onnx" as const uchar ExtModelNuSVRF[];
#resource "models\\nu_svr_double.onnx" as const uchar ExtModelNuSVRD[];
#resource "models\\random_forest_regressor_float.onnx" as const uchar ExtModelRandomForestRegressorF[];
#resource "models\\random_forest_regressor_double.onnx" as const uchar ExtModelRandomForestRegressorD[];
#resource "models\\gradient_boosting_regressor_float.onnx" as const uchar ExtModelGradientBoostingRegressorF[];
#resource "models\\gradient_boosting_regressor_double.onnx" as const uchar ExtModelGradientBoostingRegressorD[];
#resource "models\\hist_gradient_boosting_regressor_float.onnx" as const uchar ExtModelHistGradientBoostingRegressorF[];
#resource "models\\hist_gradient_boosting_regressor_double.onnx" as const uchar ExtModelHistGradientBoostingRegressorD[];
#resource "models\\svr_float.onnx" as const uchar ExtModelSVRF[];
#resource "models\\svr_double.onnx" as const uchar ExtModelSVRD[];

//--- float and double ONNX
#define ModelARDRegression               1
#define ModelBayesianRidge               2
#define ModelElasticNet                  3
#define ModelElasticNetCV                4
#define ModelHuberRegressor              5
#define ModelLars                        6
#define ModelLarsCV                      7
#define ModelLasso                       8
#define ModelLassoCV                     9
#define ModelLassoLars                  10
#define ModelLassoLarsCV                11
#define ModelLassoLarsIC                12
#define ModelLinearRegression           13
#define ModelRidge                      14
#define ModelRidgeCV                    15
#define ModelOrthogonalMatchingPursuit  16
#define ModelPassiveAggressiveRegressor 17
#define ModelQuantileRegressor          18
#define ModelRANSACRegressor            19
#define ModelTheilSenRegressor          20
#define ModelLinearSVR                  21
#define ModelMLPRegressor               22
#define ModelPLSRegression              23
#define ModelTweedieRegressor           24
#define ModelPoissonRegressor           25
#define ModelRadiusNeighborsRegressor   26
#define ModelKNeighborsRegressor        27
#define ModelGaussianProcessRegressor   28
#define ModelGammaRegressor             29
#define ModelSGDRegressor               30

//--- only float ONNX models
#define ModelAdaBoostRegressor             31
#define ModelBaggingRegressor              32
#define ModelDecisionTreeRegressor         33
#define ModelExtraTreeRegressor            34
#define ModelExtraTreesRegressor           35
#define ModelNuSVR                         36
#define ModelRandomForestRegressor         37
#define ModelGradientBoostingRegressor     38
#define ModelHistGradientBoostingRegressor 39
#define ModelSVR                           40

//---
#define StrModelDouble " (double)";
#define StrModelFloat  " (float)";

//+------------------------------------------------------------------+
//| CreateModel                                                      |
//+------------------------------------------------------------------+
long CreateModel(const int model_id,const int model_type,string &model_name)
  {
   long model_handle=INVALID_HANDLE;
   ulong flags=ONNX_DEFAULT;
//ulong flags=ONNX_DEBUG_LOGS;
//---
   switch(model_id)
     {
      //---
      case ModelARDRegression:
        {
         model_name="ARDRegression";
         //---
         if(model_type==TestFloatModel)
            model_handle=OnnxCreateFromBuffer(ExtModelARDRegressionF,flags);
         else
            if(model_type==TestDoubleModel)
               model_handle=OnnxCreateFromBuffer(ExtModelARDRegressionD,flags);
         break;
        }
      //---
      case ModelBayesianRidge:
        {
         model_name="BayesianRidge";
         //---
         if(model_type==TestFloatModel)
            model_handle=OnnxCreateFromBuffer(ExtModelBayesianRidgeF,flags);
         else
            if(model_type==TestDoubleModel)
               model_handle=OnnxCreateFromBuffer(ExtModelBayesianRidgeD,flags);
         break;
        }
      //---
      case ModelElasticNet:
        {
         model_name="ElasticNet";
         //---
         if(model_type==TestFloatModel)
            model_handle=OnnxCreateFromBuffer(ExtModelElasticNetF,flags);
         else
            if(model_type==TestDoubleModel)
               model_handle=OnnxCreateFromBuffer(ExtModelElasticNetD,flags);
         break;
        }
      //---
      case ModelElasticNetCV:
        {
         model_name="ElasticNetCV";
         //---
         if(model_type==TestFloatModel)
            model_handle=OnnxCreateFromBuffer(ExtModelElasticNetCVF,flags);
         else
            if(model_type==TestDoubleModel)
               model_handle=OnnxCreateFromBuffer(ExtModelElasticNetCVD,flags);
         break;
        }
      //---
      case ModelHuberRegressor:
        {
         model_name="HuberRegressor";
         //---
         if(model_type==TestFloatModel)
            model_handle=OnnxCreateFromBuffer(ExtModelHuberRegressorF,flags);
         else
            if(model_type==TestDoubleModel)
               model_handle=OnnxCreateFromBuffer(ExtModelHuberRegressorD,flags);
         break;
        }
      //---
      case ModelLars:
        {
         model_name="Lars";
         //---
         if(model_type==TestFloatModel)
            model_handle=OnnxCreateFromBuffer(ExtModelLarsF,flags);
         else
            if(model_type==TestDoubleModel)
               model_handle=OnnxCreateFromBuffer(ExtModelLarsD,flags);
         break;
        }
      //---
      case ModelLarsCV:
        {
         model_name="LarsCV";
         //---
         if(model_type==TestFloatModel)
            model_handle=OnnxCreateFromBuffer(ExtModelLarsCVF,flags);
         else
            if(model_type==TestDoubleModel)
               model_handle=OnnxCreateFromBuffer(ExtModelLarsCVD,flags);
         break;
        }
      //---
      case ModelLasso:
        {
         model_name="Lasso";
         //---
         if(model_type==TestFloatModel)
            model_handle=OnnxCreateFromBuffer(ExtModelLassoF,flags);
         else
            if(model_type==TestDoubleModel)
               model_handle=OnnxCreateFromBuffer(ExtModelLassoD,flags);
         break;
        }
      //---
      case ModelLassoCV:
        {
         model_name="LassoCV";
         //---
         if(model_type==TestFloatModel)
            model_handle=OnnxCreateFromBuffer(ExtModelLassoCVF,flags);
         else
            if(model_type==TestDoubleModel)
               model_handle=OnnxCreateFromBuffer(ExtModelLassoCVD,flags);
         break;
        }
      //---
      case ModelLassoLars:
        {
         model_name="LassoLars";
         //---
         if(model_type==TestFloatModel)
            model_handle=OnnxCreateFromBuffer(ExtModelLassoLarsF,flags);
         else
            if(model_type==TestDoubleModel)
               model_handle=OnnxCreateFromBuffer(ExtModelLassoLarsD,flags);
         break;
        }
      //---
      case ModelLassoLarsCV:
        {
         model_name="LassoLarsCV";
         //---
         if(model_type==TestFloatModel)
            model_handle=OnnxCreateFromBuffer(ExtModelLassoLarsCVF,flags);
         else
            if(model_type==TestDoubleModel)
               model_handle=OnnxCreateFromBuffer(ExtModelLassoLarsCVD,flags);
         break;
        }
      //---
      case ModelLassoLarsIC:
        {
         model_name="LassoLarsIC";
         //---
         if(model_type==TestFloatModel)
            model_handle=OnnxCreateFromBuffer(ExtModelLassoLarsICF,flags);
         else
            if(model_type==TestDoubleModel)
               model_handle=OnnxCreateFromBuffer(ExtModelLassoLarsICD,flags);
         break;
        }
      //---
      case ModelLinearRegression:
        {
         model_name="LinearRegression";
         //---
         if(model_type==TestFloatModel)
            model_handle=OnnxCreateFromBuffer(ExtModelLinearRegressionF,flags);
         else
            if(model_type==TestDoubleModel)
               model_handle=OnnxCreateFromBuffer(ExtModelLinearRegressionD,flags);
         break;
        }
      //---
      case ModelRidge:
        {
         model_name="Ridge";
         //---
         if(model_type==TestFloatModel)
            model_handle=OnnxCreateFromBuffer(ExtModelRidgeF,flags);
         else
            if(model_type==TestDoubleModel)
               model_handle=OnnxCreateFromBuffer(ExtModelRidgeD,flags);
         break;
        }
      //---
      case ModelRidgeCV:
        {
         model_name="RidgeCV";
         //---
         if(model_type==TestFloatModel)
            model_handle=OnnxCreateFromBuffer(ExtModelRidgeCVF,flags);
         else
            if(model_type==TestDoubleModel)
               model_handle=OnnxCreateFromBuffer(ExtModelRidgeCVD,flags);
         break;
        }
      //---
      case ModelOrthogonalMatchingPursuit:
        {
         model_name="OrthogonalMatchingPursuit";
         //---
         if(model_type==TestFloatModel)
            model_handle=OnnxCreateFromBuffer(ExtModelOMPF,flags);
         else
            if(model_type==TestDoubleModel)
               model_handle=OnnxCreateFromBuffer(ExtModelOMPD,flags);
         break;
        }
      //---
      case ModelPassiveAggressiveRegressor:
        {
         model_name="PassiveAggressiveRegressor";
         //---
         if(model_type==TestFloatModel)
            model_handle=OnnxCreateFromBuffer(ExtModelPAF,flags);
         else
            if(model_type==TestDoubleModel)
               model_handle=OnnxCreateFromBuffer(ExtModelPAD,flags);
         break;
        }
      //---
      case ModelQuantileRegressor:
        {
         model_name="QuantileRegressor";
         //---
         if(model_type==TestFloatModel)
            model_handle=OnnxCreateFromBuffer(ExtModelQuantileRegressorF,flags);
         else
            if(model_type==TestDoubleModel)
               model_handle=OnnxCreateFromBuffer(ExtModelQuantileRegressorD,flags);
         break;
        }
      //---
      case ModelRANSACRegressor:
        {
         model_name="RANSACRegressor";
         //---
         if(model_type==TestFloatModel)
            model_handle=OnnxCreateFromBuffer(ExtModelRANSACRegressorF,flags);
         else
            if(model_type==TestDoubleModel)
               model_handle=OnnxCreateFromBuffer(ExtModelRANSACRegressorD,flags);
         break;
        }
      //---
      case ModelTheilSenRegressor:
        {
         model_name="TheilSenRegressor";
         //---
         if(model_type==TestFloatModel)
            model_handle=OnnxCreateFromBuffer(ExtModelTheilSenRegressorF,flags);
         else
            if(model_type==TestDoubleModel)
               model_handle=OnnxCreateFromBuffer(ExtModelTheilSenRegressorD,flags);
         break;
        }
      //---
      case ModelLinearSVR:
        {
         model_name="LinearSVR";
         //---
         if(model_type==TestFloatModel)
            model_handle=OnnxCreateFromBuffer(ExtModelLinearSVRF,flags);
         else
            if(model_type==TestDoubleModel)
               model_handle=OnnxCreateFromBuffer(ExtModelLinearSVRD,flags);
         break;
        }
      //---
      case ModelMLPRegressor:
        {
         model_name="MLPRegressor";
         //---
         if(model_type==TestFloatModel)
            model_handle=OnnxCreateFromBuffer(ExtModelMLPRegressorF,flags);
         else
            if(model_type==TestDoubleModel)
               model_handle=OnnxCreateFromBuffer(ExtModelMLPRegressorD,flags);
         break;
        }
      //---
      case ModelPLSRegression:
        {
         model_name="PLSRegression";
         //---
         if(model_type==TestFloatModel)
            model_handle=OnnxCreateFromBuffer(ExtModelPLSRegressionF,flags);
         else
            if(model_type==TestDoubleModel)
               model_handle=OnnxCreateFromBuffer(ExtModelPLSRegressionD,flags);
         break;
        }
      //---
      case ModelTweedieRegressor:
        {
         model_name="TweedieRegressor";
         //---
         if(model_type==TestFloatModel)
            model_handle=OnnxCreateFromBuffer(ExtModelTweedieRegressorF,flags);
         else
            if(model_type==TestDoubleModel)
               model_handle=OnnxCreateFromBuffer(ExtModelTweedieRegressorD,flags);
         break;
        }
      //---
      case ModelPoissonRegressor:
        {
         model_name="PoissonRegressor";
         //---
         if(model_type==TestFloatModel)
            model_handle=OnnxCreateFromBuffer(ExtModelPoissonRegressorF,flags);
         else
            if(model_type==TestDoubleModel)
               model_handle=OnnxCreateFromBuffer(ExtModelPoissonRegressorD,flags);
         break;
        }
      //---
      case ModelRadiusNeighborsRegressor:
        {
         model_name="RadiusNeighborsRegressor";
         //---
         if(model_type==TestFloatModel)
            model_handle=OnnxCreateFromBuffer(ExtModelRadiusNeighborsRegressorF,flags);
         else
            if(model_type==TestDoubleModel)
               model_handle=OnnxCreateFromBuffer(ExtModelRadiusNeighborsRegressorD,flags);
         break;
        }
      //---
      case ModelKNeighborsRegressor:
        {
         model_name="KNeighborsRegressor";
         //---
         if(model_type==TestFloatModel)
            model_handle=OnnxCreateFromBuffer(ExtModelKNeighborsRegressorF,flags);
         else
            if(model_type==TestDoubleModel)
               model_handle=OnnxCreateFromBuffer(ExtModelKNeighborsRegressorD,flags);
         break;
        }
      //---
      case ModelGaussianProcessRegressor:
        {
         model_name="GaussianProcessRegressor";
         //---
         if(model_type==TestFloatModel)
            model_handle=OnnxCreateFromBuffer(ExtModelGaussianProcessRegressorF,flags);
         else
            if(model_type==TestDoubleModel)
               model_handle=OnnxCreateFromBuffer(ExtModelGaussianProcessRegressorD,flags);
         break;
        }
      //---
      case ModelGammaRegressor:
        {
         model_name="GammaRegressor";
         //---
         if(model_type==TestFloatModel)
            model_handle=OnnxCreateFromBuffer(ExtModelGammaRegressorF,flags);
         else
            if(model_type==TestDoubleModel)
               model_handle=OnnxCreateFromBuffer(ExtModelGammaRegressorD,flags);
         break;
        }
      //---
      case ModelSGDRegressor:
        {
         model_name="SGDRegressor";
         //---
         if(model_type==TestFloatModel)
            model_handle=OnnxCreateFromBuffer(ExtModelSGDRegressorF,flags);
         else
            if(model_type==TestDoubleModel)
               model_handle=OnnxCreateFromBuffer(ExtModelSGDRegressorD,flags);
         break;
        }
      //---
      case ModelAdaBoostRegressor:
        {
         model_name="AdaBoostRegressor";
         //---
         if(model_type==TestFloatModel)
            model_handle=OnnxCreateFromBuffer(ExtModelAdaBoostRegressorF,flags);
         else
            if(model_type==TestDoubleModel)
               model_handle=OnnxCreateFromBuffer(ExtModelAdaBoostRegressorD,flags);
         break;
        }
      //---
      case ModelBaggingRegressor:
        {
         model_name="BaggingRegressor";
         //---
         if(model_type==TestFloatModel)
            model_handle=OnnxCreateFromBuffer(ExtModelBaggingRegressorF,flags);
         else
            if(model_type==TestDoubleModel)
               model_handle=OnnxCreateFromBuffer(ExtModelBaggingRegressorD,flags);
         break;
        }
      //---
      case ModelDecisionTreeRegressor:
        {
         model_name="DecisionTreeRegressor";
         //---
         if(model_type==TestFloatModel)
            model_handle=OnnxCreateFromBuffer(ExtModelDecisionTreeRegressorF,flags);
         else
            if(model_type==TestDoubleModel)
               model_handle=OnnxCreateFromBuffer(ExtModelDecisionTreeRegressorD,flags);
         break;
        }
      //---
      case ModelExtraTreeRegressor:
        {
         model_name="ExtraTreeRegressor";
         //---
         if(model_type==TestFloatModel)
            model_handle=OnnxCreateFromBuffer(ExtModelExtraTreeRegressorF,flags);
         else
            if(model_type==TestDoubleModel)
               model_handle=OnnxCreateFromBuffer(ExtModelExtraTreeRegressorD,flags);
         break;
        }
      //---
      case ModelExtraTreesRegressor:
        {
         model_name="ExtraTreesRegressor";
         //---
         if(model_type==TestFloatModel)
            model_handle=OnnxCreateFromBuffer(ExtModelExtraTreesRegressorF,flags);
         else
            if(model_type==TestDoubleModel)
               model_handle=OnnxCreateFromBuffer(ExtModelExtraTreesRegressorD,flags);
         break;
        }
      case ModelNuSVR:
        {
         model_name="NuSVR";
         //---
         if(model_type==TestFloatModel)
            model_handle=OnnxCreateFromBuffer(ExtModelNuSVRF,flags);
         else
            if(model_type==TestDoubleModel)
               model_handle=OnnxCreateFromBuffer(ExtModelNuSVRD,flags);
         break;
        }
      //---
      case ModelRandomForestRegressor:
        {
         model_name="RandomForestRegressor";
         //---
         if(model_type==TestFloatModel)
            model_handle=OnnxCreateFromBuffer(ExtModelRandomForestRegressorF,flags);
         else
            if(model_type==TestDoubleModel)
               model_handle=OnnxCreateFromBuffer(ExtModelRandomForestRegressorD,flags);
         break;
        }
      //---
      case ModelGradientBoostingRegressor:
        {
         model_name="GradientBoostingRegressor";
         //---
         if(model_type==TestFloatModel)
            model_handle=OnnxCreateFromBuffer(ExtModelGradientBoostingRegressorF,flags);
         else
            if(model_type==TestDoubleModel)
               model_handle=OnnxCreateFromBuffer(ExtModelGradientBoostingRegressorD,flags);
         break;
        }
      //---
      case ModelHistGradientBoostingRegressor:
        {
         model_name="HistGradientBoostingRegressor";
         //---
         if(model_type==TestFloatModel)
            model_handle=OnnxCreateFromBuffer(ExtModelHistGradientBoostingRegressorF,flags);
         else
            if(model_type==TestDoubleModel)
               model_handle=OnnxCreateFromBuffer(ExtModelHistGradientBoostingRegressorD,flags);
         break;
        }
      //---
      case ModelSVR:
        {
         model_name="SVR";
         //---
         if(model_type==TestFloatModel)
            model_handle=OnnxCreateFromBuffer(ExtModelSVRF,flags);
         else
            if(model_type==TestDoubleModel)
               model_handle=OnnxCreateFromBuffer(ExtModelSVRD,flags);
         break;
        }
      //---
      default:
         break;
     }
//---
   if(model_type==TestFloatModel)
      model_name+=StrModelFloat;
//---
   if(model_type==TestDoubleModel)
      model_name+=StrModelDouble;
//---
   return(model_handle);
  }

//+------------------------------------------------------------------+
//| Calculate regression using float values                          |
//+------------------------------------------------------------------+
bool RunModelFloat(long model,vector &input_vector, vector &output_vector)
  {
//--- check number of input samples
   ulong batch_size=input_vector.Size();
   if(batch_size==0)
      return(false);
//--- prepare output array
   output_vector.Resize((int)batch_size);
//--- prepare input tensor
   float input_data[];
   ArrayResize(input_data,(int)batch_size);
//--- set input shape
   ulong input_shape[]= {batch_size, 1};
   OnnxSetInputShape(model,0,input_shape);
//--- copy data to the input tensor
   for(int k=0; k<(int)batch_size; k++)
      input_data[k]=(float)input_vector[k];
//--- prepare output tensor
   float output_data[];
   ArrayResize(output_data,(int)batch_size);
//--- set output shape
   ulong output_shape[]= {batch_size,1};
   OnnxSetOutputShape(model,0,output_shape);
//--- run the model
   bool res=OnnxRun(model,ONNX_DEBUG_LOGS,input_data,output_data);
//--- copy output to vector
   if(res)
     {
      for(int k=0; k<(int)batch_size; k++)
         output_vector[k]=output_data[k];
     }
//---
   return(res);
  }
//+------------------------------------------------------------------+
//| Calculate regression using double values                         |
//+------------------------------------------------------------------+
bool RunModelDouble(long model,vector &input_vector, vector &output_vector)
  {
//--- check number of input samples
   ulong batch_size=input_vector.Size();
   if(batch_size==0)
      return(false);
//--- prepare output array
   output_vector.Resize((int)batch_size);
//--- prepare input tensor
   double input_data[];
   ArrayResize(input_data,(int)batch_size);
//--- set input shape
   ulong input_shape[]= {batch_size, 1};
   OnnxSetInputShape(model,0,input_shape);
//--- copy data to the input tensor
   for(int k=0; k<(int)batch_size; k++)
      input_data[k]=input_vector[k];
//--- prepare output tensor
   double output_data[];
   ArrayResize(output_data,(int)batch_size);
//--- set output shape
   ulong output_shape[]= {batch_size,1};
   OnnxSetOutputShape(model,0,output_shape);
//--- run the model
   bool res=OnnxRun(model,ONNX_DEBUG_LOGS,input_data,output_data);
//--- copy output to vector
   if(res)
     {
      for(int k=0; k<(int)batch_size; k++)
         output_vector[k]=output_data[k];
     }
//---
   return(res);
  }

//+------------------------------------------------------------------+
//| Generate synthetic data                                          |
//+------------------------------------------------------------------+
bool GenerateData(const int n,vector &x,vector &y)
  {
   if(n<=0)
      return(false);
//--- prepare arrays
   x.Resize(n);
   y.Resize(n);
//---
   for(int i=0; i<n; i++)
     {
      x[i]=(double)1.0*i;
      y[i]=(double)(4*x[i] + 10*sin(x[i]*0.5));
     }
//---
   return(true);
  }
//+------------------------------------------------------------------+
//| TestRegressionModel                                              |
//+------------------------------------------------------------------+
bool TestRegressionModel(const long model,const string model_name,const int model_type)
  {
//---
   ulong flags=ONNX_DEFAULT;

   if(model_type==TestFloatModel)
     {
      PrintFormat("Testing ONNX float: %s ",model_name);
      //model=OnnxCreateFromBuffer(ExtModelFloat,flags);
     }
   else
      if(model_type==TestDoubleModel)
        {
         PrintFormat("Testing ONNX double: %s ",model_name);
         //model=OnnxCreateFromBuffer(ExtModelDouble,flags);
        }
      else
        {
         PrintFormat("Model type is not incorrect.");
         return(false);
        }
//---
   vector x_values= {};
   vector y_true= {};
   vector y_predicted= {};
//---
   int n=100;
   GenerateData(n,x_values,y_true);
//---
   bool run_result=false;
   if(model_type==TestFloatModel)
     {
      run_result=RunModelFloat(model,x_values,y_predicted);
     }
   else
      if(model_type==TestDoubleModel)
        {
         run_result=RunModelDouble(model,x_values,y_predicted);
        }
//---
   if(run_result)
     {
      PrintFormat("MQL5:   R-Squared (Coefficient of determination): %.16f",y_predicted.RegressionMetric(y_true,REGRESSION_R2));
      PrintFormat("MQL5:   Mean Absolute Error: %.16f",y_predicted.RegressionMetric(y_true,REGRESSION_MAE));
      PrintFormat("MQL5:   Mean Squared Error: %.16f",y_predicted.RegressionMetric(y_true,REGRESSION_MSE));
     }
   else
      PrintFormat("Error %d",GetLastError());
//--- release model
   OnnxRelease(model);
//---
   return(true);
  }

//+------------------------------------------------------------------+
//| Script program start function                                    |
//+------------------------------------------------------------------+
int OnStart(void)
  {
//---
   string model_name;
//--- test ONNX models (float)
   int model_type=TestFloatModel;
   Print("Testing ONNX float models...");
   for(int model_id=1; model_id<=40; model_id++)
     {
      long model_handle=CreateModel(model_id,model_type,model_name);
      if(model_handle!=INVALID_HANDLE)
        {
         PrintFormat("\nid=%d Name=%s",model_id, model_name);
         //---
         TestRegressionModel(model_handle,model_name,model_type);
        }
      else
         PrintFormat("id=%d model_name=%s Error=%d\n",model_id,model_name,GetLastError());
     }
//--- test ONNX models (double)
   model_type=TestDoubleModel;
   Print("\nTesting ONNX double models...");
   for(int model_id=1; model_id<=30; model_id++)
     {
      long model_handle=CreateModel(model_id,model_type,model_name);
      if(model_handle!=INVALID_HANDLE)
        {
         PrintFormat("\nid=%d Name=%s",model_id, model_name);
         //---
         TestRegressionModel(model_handle,model_name,model_type);
        }
      else
         PrintFormat("id=%d model_name=%s Error=%d\n",model_id,model_name,GetLastError());
     }
//--- test ONNX models (ONNX double execution errors)
   /*model_type=TestDoubleModel;
   Print("\nTesting ONNX double models with errors...");
   for(int model_id=31; model_id<=40; model_id++)
     {
      long model_handle=CreateModel(model_id,model_type,model_name);
      if(model_handle!=INVALID_HANDLE)
        {
         PrintFormat("\nid=%d Name=%s",model_id, model_name);
         //---
         TestRegressionModel(model_handle,model_name,model_type);
        }
      else
         PrintFormat("id=%d model_name=%s Error=%d\n",model_id,model_name,GetLastError());
     }*/
//---
   return(0);
  }
//+------------------------------------------------------------------+

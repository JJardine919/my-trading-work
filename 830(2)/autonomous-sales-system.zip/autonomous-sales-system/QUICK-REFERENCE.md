# Quick Reference Guide

## 🚀 Getting Started (5 Minutes)

### 1. Create Accounts
- n8n Cloud → https://n8n.io
- Airtable → https://airtable.com
- SendGrid → https://sendgrid.com
- Stripe → https://stripe.com

### 2. Set Up Airtable
- Create base: "Sales CRM"
- Create tables: "Leads" and "Orders"
- Copy Base ID from URL

### 3. Import n8n Workflows
- Upload 4 JSON files from `n8n-workflows/`
- Add credentials for all services
- Copy webhook URLs

### 4. Deploy Landing Page
- Edit `lead-capture-template.html`
- Add your n8n webhook URL
- Deploy to Vercel/Netlify

### 5. Test
- Submit form → Check Airtable → Verify email
- Complete test purchase → Check order created

---

## 📋 System Components

| Component | Purpose | Setup Time |
|-----------|---------|------------|
| Airtable | CRM & Database | 15 min |
| n8n | Automation Engine | 30 min |
| SendGrid | Email Delivery | 10 min |
| Stripe | Payments | 15 min |
| Landing Page | Lead Capture | 20 min |
| Google Sheets | Analytics | 10 min |

**Total Setup: ~2 hours**

---

## 🔗 Important URLs

### Webhooks (Get from n8n)
```
Lead Capture: https://your-n8n.com/webhook/lead-capture
Stripe Events: https://your-n8n.com/webhook/stripe-webhook
```

### Dashboards
```
Airtable CRM: https://airtable.com/[YOUR_BASE_ID]
n8n Workflows: https://your-n8n.com/workflows
Stripe Dashboard: https://dashboard.stripe.com
SendGrid Dashboard: https://app.sendgrid.com
```

---

## ⚙️ Configuration Checklist

### n8n Credentials Needed
- [ ] Airtable (Access Token)
- [ ] SendGrid (API Key)
- [ ] Stripe (Secret Key)
- [ ] Slack (Webhook URL or OAuth)
- [ ] Google Sheets (OAuth)

### Airtable Setup
- [ ] Base created: "Sales CRM"
- [ ] Table: "Leads" (12 fields)
- [ ] Table: "Orders" (10 fields)
- [ ] Views configured
- [ ] API token generated

### Email Setup
- [ ] SendGrid account verified
- [ ] Sender email verified
- [ ] API key generated
- [ ] Unsubscribe link added to emails

### Payment Setup
- [ ] Stripe account created
- [ ] Products created
- [ ] Payment links generated
- [ ] Webhook configured

---

## 📊 Key Metrics to Track

| Metric | Target | Formula |
|--------|--------|---------|
| Lead Capture Rate | 20-30% | (Leads / Visitors) × 100 |
| Email Open Rate | 25-35% | (Opens / Sent) × 100 |
| Email Click Rate | 3-5% | (Clicks / Opens) × 100 |
| Conversion Rate | 2-5% | (Customers / Leads) × 100 |
| Avg Order Value | $500+ | Total Revenue / Orders |
| ROI | 5-10x | Revenue / (Ad Spend + Costs) |

---

## 🔥 Lead Scoring

| Factor | Points | Total |
|--------|--------|-------|
| **Source** | | |
| Referral | +40 | |
| Paid Ad | +30 | |
| Organic | +20 | |
| **Data Quality** | | |
| Email provided | +20 | |
| Phone provided | +15 | |
| Company provided | +15 | |
| High budget | +20 | |

**Score Ranges:**
- 0-40: Cold
- 41-60: Warm
- 61-100: Hot

---

## 📧 Email Sequence Timeline

| Day | Email | Subject Example | Goal |
|-----|-------|----------------|------|
| 0 | Welcome | "Here's Your Free Guide" | Deliver value |
| 2 | Education | "The #1 Mistake People Make" | Build trust |
| 4 | Solution | "How [Product] Can Help" | Show benefits |
| 6 | Social Proof | "Real Results: Customer Story" | Build credibility |
| 8 | Offer | "20% Off - Limited Time" | Drive purchase |
| 10 | Urgency | "Last Chance: Offer Expires" | Create FOMO |

---

## 🛠️ Common Commands

### n8n
```bash
# Self-hosted
npm install n8n -g
n8n start

# Docker
docker run -it --rm --name n8n -p 5678:5678 -v ~/.n8n:/home/node/.n8n n8nio/n8n
```

### Deploy Landing Page
```bash
# Vercel
npm install -g vercel
cd landing-pages/
vercel --prod

# Netlify
npm install -g netlify-cli
netlify deploy --prod --dir=landing-pages
```

---

## 🐛 Quick Troubleshooting

| Issue | Solution |
|-------|----------|
| Leads not captured | Check webhook URL, verify n8n active |
| Emails not sending | Verify SendGrid API key & sender |
| Payment failed | Check Stripe webhook & signing secret |
| Analytics not updating | Verify Google Sheet ID & permissions |
| High unsubscribe rate | Reduce frequency, improve content |

---

## 💰 Cost Calculator

### Fixed Costs
- n8n Cloud: $20/month
- Domain: $1/month
- **Total: $21/month**

### Variable Costs
- Stripe: 2.9% + $0.30 per transaction
- SendGrid: Free (100 emails/day) → $15/month (40k emails)
- Airtable: Free (1,200 records) → $20/month (unlimited)

### Example Revenue
```
100 leads/month
× 3% conversion rate
= 3 customers
× $500 average order
= $1,500 revenue/month

Cost: $21 + $4.50 (Stripe fees) = $25.50
Profit: $1,474.50
ROI: 5,780%
```

---

## 🎯 Success Milestones

### Week 1
- [ ] System fully set up
- [ ] 10+ test leads captured
- [ ] 1 test purchase completed
- [ ] Analytics working

### Month 1
- [ ] 100+ real leads
- [ ] 2-5 real customers
- [ ] $1,000+ revenue
- [ ] Key metrics baseline established

### Month 3
- [ ] 500+ leads
- [ ] 15-25 customers
- [ ] $7,500+ revenue
- [ ] Optimized funnel (tested variations)

### Month 6
- [ ] 1,500+ leads
- [ ] 50-75 customers
- [ ] $25,000+ revenue
- [ ] Scaling profitably

---

## 📞 Support Resources

### Documentation
- This System: README.md, SETUP-GUIDE.md
- n8n: https://docs.n8n.io
- Airtable: https://support.airtable.com
- Stripe: https://stripe.com/docs
- SendGrid: https://docs.sendgrid.com

### Communities
- n8n: https://community.n8n.io
- Reddit: r/n8n, r/nocode, r/startups
- Discord: n8n Community Server

### Tools
- Webhook Testing: https://webhook.site
- Email Testing: https://mailtrap.io
- UTM Builder: https://ga-dev-tools.web.app/campaign-url-builder/

---

## 🔐 Security Checklist

- [ ] All API keys stored in n8n credentials (not in code)
- [ ] Stripe webhook has signing secret
- [ ] SendGrid sender domain verified (SPF/DKIM)
- [ ] Airtable access restricted to team only
- [ ] HTTPS enabled on landing pages
- [ ] Privacy policy published
- [ ] GDPR unsubscribe implemented
- [ ] Regular backups scheduled

---

## 🚀 Optimization Ideas

### Landing Page
- A/B test headlines
- Simplify form (fewer fields = higher conversion)
- Add video testimonials
- Implement exit-intent popup
- Speed optimization (< 3 seconds load)

### Email Sequence
- Test send times (usually 10 AM or 2 PM local)
- Personalize beyond name (location, interests)
- Segment by behavior (clicked vs not clicked)
- Add GIFs or images
- Mobile optimization

### Lead Scoring
- Track page visits (heat maps)
- Score email engagement
- Add firmographic data (company size, industry)
- Implement predictive scoring (ML)

### Conversion
- Offer payment plans
- Add money-back guarantee
- Include live chat
- Create urgency (limited spots)
- Reduce friction (1-click purchase)

---

## 📱 Mobile Quick Actions

### Daily Check (5 min)
1. Open Google Sheets dashboard
2. Check Slack for notifications
3. Review hot leads in Airtable
4. Respond to high-value inquiries

### Weekly Review (30 min)
1. Export analytics to CSV
2. Calculate conversion rates
3. Review email performance
4. Update ad campaigns
5. Plan next week's improvements

### Monthly Analysis (2 hours)
1. Full funnel analysis
2. ROI calculation
3. Customer interviews
4. Strategy adjustments
5. Documentation updates

---

## 🎓 Learning Path

1. **Beginner:** Follow SETUP-GUIDE.md exactly
2. **Intermediate:** Customize email templates & scoring
3. **Advanced:** Add SMS, chatbot, multiple funnels
4. **Expert:** Build predictive models, enterprise integrations

---

## 🏆 Best Practices

### Lead Management
- Respond to hot leads within 1 hour
- Follow up on warm leads weekly
- Re-engage cold leads monthly
- Archive lost leads after 6 months

### Email Marketing
- Never buy email lists
- Always include unsubscribe link
- Segment by behavior and interests
- Test before sending to full list
- Monitor deliverability rates

### Analytics
- Review metrics daily
- Export data weekly
- Deep analysis monthly
- Pivot strategy quarterly

### Compliance
- Include privacy policy
- Honor unsubscribe immediately
- Store data securely
- Delete on request (GDPR)
- Document everything

---

## ⚡ Speed Run (For Experienced Users)

```bash
# 1. Accounts (10 min)
- n8n.io, airtable.com, sendgrid.com, stripe.com

# 2. Airtable (5 min)
- Create base, import schema from airtable-templates/schema.md

# 3. n8n (15 min)
- Import 4 workflows, add credentials, activate

# 4. Landing Page (5 min)
- Edit HTML, update webhook URL, deploy to Vercel

# 5. Test (5 min)
- Submit form, complete purchase, verify automation

# Total: 40 minutes for experienced users
```

---

## 📄 File Quick Reference

```
📁 autonomous-sales-system/
  📄 README.md              ← Start here
  📄 ARCHITECTURE.md        ← System design
  📄 SETUP-GUIDE.md         ← Step-by-step setup
  📄 QUICK-REFERENCE.md     ← This file

  📁 n8n-workflows/
    📄 01-lead-capture-routing.json
    📄 02-email-nurture-sequence.json
    📄 03-payment-sales-automation.json
    📄 04-analytics-reporting.json

  📁 landing-pages/
    📄 lead-capture-template.html

  📁 airtable-templates/
    📄 schema.md
```

---

## 🎬 Next Steps

1. **Read:** README.md (10 min)
2. **Follow:** SETUP-GUIDE.md (3 hours)
3. **Import:** n8n workflows (30 min)
4. **Deploy:** Landing page (20 min)
5. **Test:** Complete funnel (15 min)
6. **Launch:** Drive traffic (ongoing)

---

**Ready to automate your sales? Let's go! 🚀**

Print this page and keep it handy during setup!

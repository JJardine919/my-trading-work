# Airtable CRM Schema

This document provides the exact structure needed for your Airtable CRM base.

## Base Name
`Sales CRM`

---

## Table 1: Leads

### Purpose
Store and manage all incoming leads with scoring and status tracking.

### Fields

| Field Name | Type | Configuration | Example Value |
|------------|------|---------------|---------------|
| **Lead ID** | Single line text | Primary field | LEAD-1698765432000 |
| **Name** | Single line text | | John Smith |
| **Email** | Email | | john@example.com |
| **Phone** | Phone number | Format: (###) ###-#### | (555) 123-4567 |
| **Company** | Single line text | | Acme Corp |
| **Source** | Single select | Options listed below | paid-ad |
| **Lead Score** | Number | Integer, 0-100 | 75 |
| **Status** | Single select | Options listed below | hot |
| **Created At** | Date | Include time, GMT | 2025-01-15 10:30 AM |
| **Last Contact** | Date | Include time, GMT | 2025-01-17 2:45 PM |
| **Lifetime Value** | Currency | USD, Precision: 2, Allow negative: No | $500.00 |
| **Last Purchase** | Date | | 2025-01-20 |
| **Notes** | Long text | Enable rich text | |

### Single Select Options

**Source Field:**
- `paid-ad` (Red)
- `organic` (Green)
- `referral` (Blue)
- `api` (Purple)
- `email` (Orange)
- `social` (Yellow)
- `other` (Gray)

**Status Field:**
- `cold` (Gray)
- `warm` (Yellow)
- `hot` (Red)
- `customer` (Green)
- `unsubscribed` (Dark Gray)
- `lost` (Black)

### Views

**Default View (Grid):**
- Sort by: Created At (Newest first)
- Group by: Status
- Show all fields

**Hot Leads:**
- Filter: Status = "hot"
- Sort by: Lead Score (Highest first)
- Fields: Lead ID, Name, Email, Phone, Lead Score, Source, Created At

**Customers:**
- Filter: Status = "customer"
- Sort by: Lifetime Value (Highest first)
- Fields: Lead ID, Name, Email, Lifetime Value, Last Purchase

**Need Follow-up:**
- Filter: Status NOT "customer" OR "unsubscribed", Last Contact is before 3 days ago
- Sort by: Last Contact (Oldest first)
- Fields: Lead ID, Name, Email, Status, Last Contact

---

## Table 2: Orders

### Purpose
Track all completed purchases and revenue.

### Fields

| Field Name | Type | Configuration | Example Value |
|------------|------|---------------|---------------|
| **Order ID** | Single line text | Primary field | ORD-1698765432000 |
| **Stripe Session ID** | Single line text | | cs_test_a1B2c3D4 |
| **Stripe Payment Intent** | Single line text | | pi_3ABC123def456 |
| **Customer Email** | Email | | john@example.com |
| **Customer Name** | Single line text | | John Smith |
| **Amount** | Currency | USD, Precision: 2 | $497.00 |
| **Currency** | Single line text | | USD |
| **Product** | Single line text | | Premium Package |
| **Status** | Single select | Options listed below | paid |
| **Created At** | Date | Include time, GMT | 2025-01-20 3:15 PM |
| **Fulfillment Status** | Single select | Options listed below | completed |
| **Notes** | Long text | | |

### Single Select Options

**Status Field:**
- `paid` (Green)
- `pending` (Yellow)
- `refunded` (Red)
- `failed` (Dark Red)

**Fulfillment Status:**
- `pending` (Yellow)
- `processing` (Blue)
- `completed` (Green)
- `failed` (Red)

### Views

**Default View (Grid):**
- Sort by: Created At (Newest first)
- Show all fields

**Today's Orders:**
- Filter: Created At is today
- Sort by: Amount (Highest first)
- Fields: Order ID, Customer Name, Amount, Product, Status

**Revenue Summary:**
- Group by: Product
- Show: Sum of Amount
- Sort by: Sum of Amount (Highest first)

**Pending Fulfillment:**
- Filter: Fulfillment Status = "pending" OR "processing"
- Sort by: Created At (Oldest first)
- Fields: Order ID, Customer Name, Product, Status, Fulfillment Status, Created At

---

## Table 3: Email Events (Optional)

### Purpose
Track email engagement for better analytics.

### Fields

| Field Name | Type | Configuration | Example Value |
|------------|------|---------------|---------------|
| **Event ID** | Single line text | Primary field | EVT-1698765432000 |
| **Email** | Email | | john@example.com |
| **Event Type** | Single select | Options: sent, opened, clicked, bounced, unsubscribed | opened |
| **Email Subject** | Single line text | | The #1 Mistake People Make |
| **Campaign** | Single select | Options: day2, day4, day6, day8, day10, other | day2 |
| **Created At** | Date | Include time, GMT | 2025-01-17 9:30 AM |
| **Link Clicked** | Single line text | | https://example.com/guide |

### Views

**Engagement Summary:**
- Group by: Campaign
- Show: Count of Event ID
- Sort by: Count (Highest first)

**Recent Activity:**
- Filter: Created At is within last 7 days
- Sort by: Created At (Newest first)

---

## Relationships (Optional but Recommended)

To link tables together:

### Link Leads to Orders
1. In **Orders** table, add field:
   - Name: "Customer (from Leads)"
   - Type: Link to another record
   - Link to: Leads table
   - Allow linking to multiple records: No

2. This creates a lookup field to see:
   - All orders for each lead
   - Lead status when viewing orders

### Link Email Events to Leads
1. In **Email Events** table, add field:
   - Name: "Lead"
   - Type: Link to another record
   - Link to: Leads table
   - Match by: Email field

2. Allows tracking:
   - Email engagement per lead
   - Best-performing segments

---

## Formulas (Advanced)

Add these calculated fields for better insights:

### In Leads Table

**Days Since Created:**
```
DATETIME_DIFF(NOW(), {Created At}, 'days')
```

**Days Since Last Contact:**
```
DATETIME_DIFF(NOW(), {Last Contact}, 'days')
```

**Needs Follow-up (Checkbox):**
```
AND(
  {Status} != "customer",
  {Status} != "unsubscribed",
  DATETIME_DIFF(NOW(), {Last Contact}, 'days') > 3
)
```

**Lead Quality (Single line text):**
```
IF(
  {Lead Score} >= 70,
  "🔥 High Quality",
  IF(
    {Lead Score} >= 40,
    "⚡ Medium Quality",
    "❄️ Low Quality"
  )
)
```

### In Orders Table

**Days Since Order:**
```
DATETIME_DIFF(NOW(), {Created At}, 'days')
```

**Order Size (Single line text):**
```
IF(
  {Amount} >= 1000,
  "💎 Large",
  IF(
    {Amount} >= 500,
    "⭐ Medium",
    "📦 Small"
  )
)
```

---

## Import Sample Data

To test your setup, create these sample records:

### Sample Leads

| Lead ID | Name | Email | Source | Lead Score | Status |
|---------|------|-------|--------|------------|--------|
| LEAD-001 | John Smith | john@example.com | paid-ad | 75 | hot |
| LEAD-002 | Jane Doe | jane@example.com | organic | 45 | warm |
| LEAD-003 | Bob Johnson | bob@example.com | referral | 85 | hot |
| LEAD-004 | Alice Williams | alice@example.com | social | 30 | cold |

### Sample Orders

| Order ID | Customer Email | Customer Name | Amount | Product | Status |
|----------|----------------|---------------|--------|---------|--------|
| ORD-001 | john@example.com | John Smith | $497 | Premium Package | paid |
| ORD-002 | bob@example.com | Bob Johnson | $997 | Enterprise Package | paid |

---

## Automation (Within Airtable)

Optional Airtable automations to complement n8n:

### Automation 1: Slack Notification for Hot Leads
**Trigger:** When record enters view "Hot Leads"
**Action:** Send Slack message to #sales channel

### Automation 2: Reminder for Cold Leads
**Trigger:** When "Days Since Last Contact" > 7 and Status = "cold"
**Action:** Send email to sales team or change status

### Automation 3: Customer Welcome
**Trigger:** When Status changes to "customer"
**Action:** Send internal notification to onboarding team

---

## Data Validation Rules

To maintain data quality:

1. **Email must be unique** in Leads table
   - Settings → Table → Prevent duplicate emails

2. **Required fields:**
   - Lead ID (always auto-generated)
   - Name
   - Email
   - Status

3. **Default values:**
   - Lead Score: 0
   - Status: cold
   - Created At: NOW()
   - Last Contact: NOW()

---

## Backup Strategy

1. **Weekly Exports:**
   - View → Download CSV
   - Save to Google Drive or Dropbox

2. **API Backups:**
   - Use n8n workflow to sync to Google Sheets daily
   - Create backup base in Airtable monthly

3. **Version Control:**
   - Document schema changes
   - Test in duplicate base first

---

## Privacy & Compliance

### GDPR Compliance

1. **Data Collection:**
   - Only collect necessary fields
   - Add consent checkbox to forms

2. **Data Access:**
   - Limit team access via sharing settings
   - Use field-level permissions

3. **Data Deletion:**
   - Create "Delete Request" status
   - Workflow to remove data within 30 days

4. **Unsubscribe:**
   - Honor immediately (automated)
   - Update Status to "unsubscribed"

### Security

1. **Access Control:**
   - Workspace → Sharing
   - Set team member roles (Creator, Editor, Commenter, Read-only)

2. **API Keys:**
   - Rotate quarterly
   - Use separate keys for dev/production
   - Store securely (never in code)

3. **Audit Log:**
   - Base → Settings → History
   - Review changes monthly

---

## Performance Tips

1. **Keep views simple:**
   - Limit complex formulas
   - Use filters instead of formulas when possible

2. **Archive old records:**
   - Move records older than 2 years to separate base
   - Keep active base under 10,000 records for best performance

3. **Optimize lookups:**
   - Limit linked records
   - Use rollup instead of multiple lookups

4. **Regular maintenance:**
   - Delete test records
   - Clean duplicate entries
   - Update deprecated fields

---

## Quick Setup Checklist

- [ ] Create "Sales CRM" base
- [ ] Create "Leads" table with all fields
- [ ] Configure "Source" single select options
- [ ] Configure "Status" single select options
- [ ] Create "Orders" table with all fields
- [ ] Configure "Status" single select options for Orders
- [ ] Set up recommended views
- [ ] Create sample records for testing
- [ ] Generate API token
- [ ] Copy Base ID from URL
- [ ] Test connection from n8n
- [ ] Configure sharing settings
- [ ] Set up backup routine

---

## Need Help?

- **Airtable Support:** https://support.airtable.com
- **Community Forum:** https://community.airtable.com
- **Templates:** https://airtable.com/templates
- **API Docs:** https://airtable.com/developers/web/api/introduction

Your Airtable CRM is now ready to receive leads! 🚀

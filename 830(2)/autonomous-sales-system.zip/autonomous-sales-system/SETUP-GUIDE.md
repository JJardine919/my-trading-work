# Complete Setup Guide - Autonomous Sales System

## Overview
This guide will walk you through setting up your 100% autonomous sales system from scratch. Follow these steps in order for a smooth setup.

**Estimated Setup Time:** 3-4 hours
**Monthly Cost:** $20-30
**Technical Level:** Beginner-friendly (no coding required)

---

## Table of Contents
1. [Account Setup](#1-account-setup)
2. [Airtable CRM Configuration](#2-airtable-crm-configuration)
3. [n8n Installation & Workflow Setup](#3-n8n-installation--workflow-setup)
4. [Email Service Configuration](#4-email-service-configuration)
5. [Landing Page Deployment](#5-landing-page-deployment)
6. [Stripe Payment Integration](#6-stripe-payment-integration)
7. [Analytics & Reporting Setup](#7-analytics--reporting-setup)
8. [Testing & Launch](#8-testing--launch)
9. [Ongoing Optimization](#9-ongoing-optimization)

---

## 1. Account Setup

### Required Accounts

Create accounts for the following services (all have free tiers):

#### a) n8n (Workflow Automation)
- **Option 1 - Cloud (Easier):** https://n8n.io/pricing
  - Sign up for the $20/month starter plan
  - No technical setup required

- **Option 2 - Self-Hosted (Free):**
  - Follow guide: https://docs.n8n.io/hosting/
  - Requires: VPS (DigitalOcean $6/month or Railway.app)

#### b) Airtable (CRM Database)
- URL: https://airtable.com/signup
- Plan: Free (up to 1,200 records)
- Get API key: Account → API → Generate API key

#### c) SendGrid (Email Service)
- URL: https://signup.sendgrid.com
- Plan: Free (100 emails/day)
- Verify sender email address
- Get API key: Settings → API Keys → Create API Key

#### d) Stripe (Payment Processing)
- URL: https://dashboard.stripe.com/register
- Complete business verification
- Get API keys: Developers → API keys
- Note both Test and Live keys

#### e) Slack (Team Notifications - Optional)
- URL: https://slack.com/get-started
- Create workspace or use existing
- Get webhook URL: Settings → Integrations → Incoming Webhooks

#### f) Domain & Hosting
- Domain: Namecheap, GoDaddy (~$12/year)
- Hosting: Vercel.com or Netlify (Free tier)
- Connect domain to hosting platform

#### g) Google Account (Analytics & Sheets)
- Enable Google Sheets API
- Create a new Google Sheet for analytics dashboard

---

## 2. Airtable CRM Configuration

### Step 1: Create Your Base

1. Log into Airtable
2. Click "Add a base" → "Start from scratch"
3. Name it: "Sales CRM"

### Step 2: Create Tables

#### Table 1: Leads

Create a table named "Leads" with these fields:

| Field Name | Field Type | Settings |
|------------|------------|----------|
| Lead ID | Single line text | Primary field |
| Name | Single line text | |
| Email | Email | |
| Phone | Phone number | |
| Company | Single line text | |
| Source | Single select | Options: paid-ad, organic, referral, api |
| Lead Score | Number | Integer, 0-100 |
| Status | Single select | Options: cold, warm, hot, customer, unsubscribed |
| Created At | Date | Include time |
| Last Contact | Date | Include time |
| Lifetime Value | Currency | USD |
| Last Purchase | Date | |
| Notes | Long text | |

#### Table 2: Orders

Create a table named "Orders" with these fields:

| Field Name | Field Type | Settings |
|------------|------------|----------|
| Order ID | Single line text | Primary field |
| Stripe Session ID | Single line text | |
| Customer Email | Email | |
| Customer Name | Single line text | |
| Amount | Currency | USD |
| Currency | Single line text | |
| Product | Single line text | |
| Status | Single select | Options: paid, refunded, failed |
| Created At | Date | Include time |

### Step 3: Get Your Airtable Credentials

1. Go to https://airtable.com/create/tokens
2. Create personal access token
3. Give it scopes: `data.records:read`, `data.records:write`, `schema.bases:read`
4. Copy the token - you'll need it for n8n
5. Get your Base ID:
   - Open your base
   - Look at URL: `https://airtable.com/appXXXXXXXXXXXX/...`
   - The `appXXXXXXXXXXXX` is your Base ID

---

## 3. n8n Installation & Workflow Setup

### Step 1: Set Up n8n Credentials

1. Log into your n8n instance
2. Click Settings → Credentials
3. Add credentials for:

**Airtable:**
- Name: "Airtable API"
- Access Token: [Your Airtable token]
- Test connection

**SendGrid:**
- Name: "SendGrid"
- API Key: [Your SendGrid API key]
- Test connection

**Slack (Optional):**
- Name: "Slack"
- OAuth2 or Webhook URL
- Test connection

**Stripe:**
- Name: "Stripe"
- Secret Key: [Your Stripe secret key]
- Test with test mode first

**Google Sheets:**
- Name: "Google Sheets"
- OAuth2 authentication
- Follow authorization flow

### Step 2: Import Workflows

Import each workflow JSON file from the `n8n-workflows/` folder:

1. **01-lead-capture-routing.json**
   - Click "Import from File"
   - Select the file
   - Update Airtable application IDs in all Airtable nodes
   - Update email addresses and domain names
   - Activate the workflow
   - Copy the webhook URL (you'll need this for your landing page)

2. **02-email-nurture-sequence.json**
   - Import file
   - Update Airtable application IDs
   - Customize email templates with your branding
   - Update all links to your actual URLs
   - Activate workflow

3. **03-payment-sales-automation.json**
   - Import file
   - Update Airtable application IDs
   - Configure Stripe webhook endpoint
   - Customize confirmation emails
   - Activate workflow

4. **04-analytics-reporting.json**
   - Import file
   - Update Google Sheet ID
   - Configure Slack channel
   - Set desired report schedule
   - Activate workflow

### Step 3: Configure Webhook URLs

After importing workflows, note these webhook URLs:

- **Lead Capture:** `https://your-n8n.com/webhook/lead-capture`
- **Stripe Events:** `https://your-n8n.com/webhook/stripe-webhook`

---

## 4. Email Service Configuration

### SendGrid Setup

1. **Verify Sender Email:**
   - Go to Settings → Sender Authentication
   - Click "Verify a Single Sender"
   - Enter your email (e.g., hello@yourdomain.com)
   - Verify via email confirmation

2. **Optional - Custom Domain:**
   - Go to Settings → Sender Authentication
   - Authenticate Your Domain
   - Add DNS records to your domain provider
   - Wait for verification (up to 48 hours)

3. **Create Email Templates (Optional):**
   - Go to Email API → Dynamic Templates
   - Create templates for each email in the sequence
   - Use template IDs in n8n workflows

4. **Unsubscribe Handling:**
   - Enable unsubscribe groups
   - Add unsubscribe links to all emails (required by law)
   - Create workflow to update Airtable when unsubscribe event occurs

---

## 5. Landing Page Deployment

### Step 1: Customize Landing Page

1. Open `landing-pages/lead-capture-template.html`
2. Customize these sections:
   - Company name and branding
   - Hero headline and subtitle
   - Benefits and features
   - Testimonials
   - Form fields (keep relevant ones)
   - Color scheme (update CSS variables)

3. Update the webhook URL:
```javascript
const N8N_WEBHOOK_URL = 'https://your-n8n-instance.com/webhook/lead-capture';
```

### Step 2: Deploy to Hosting

**Option A - Vercel (Recommended):**
1. Install Vercel CLI: `npm install -g vercel`
2. Navigate to landing page folder
3. Run: `vercel`
4. Follow prompts to deploy
5. Connect your custom domain

**Option B - Netlify:**
1. Go to https://app.netlify.com
2. Drag and drop your landing page folder
3. Configure custom domain
4. Deploy

**Option C - Simple Hosting:**
1. Upload HTML file to your hosting via FTP
2. Ensure it's accessible at your domain

### Step 3: Add Google Analytics (Optional)

1. Create GA4 property: https://analytics.google.com
2. Get tracking ID
3. Add tracking code to landing page
4. Set up conversion goals

---

## 6. Stripe Payment Integration

### Step 1: Create Products

1. Go to Stripe Dashboard → Products
2. Click "Add Product"
3. Create your products:
   - Name: Your product/service name
   - Price: Set pricing and billing frequency
   - Add description and images

### Step 2: Set Up Checkout

1. Go to Products → [Your Product] → Payment Links
2. Create payment link
3. Enable "Collect addresses" if needed
4. Customize success URL: `https://yourdomain.com/success`
5. Copy payment link URL

### Step 3: Configure Webhooks

1. Go to Developers → Webhooks
2. Click "Add endpoint"
3. Endpoint URL: `https://your-n8n.com/webhook/stripe-webhook`
4. Select events to listen to:
   - `checkout.session.completed`
   - `payment_intent.succeeded`
   - `customer.subscription.created`
   - `customer.subscription.deleted`
5. Copy webhook signing secret
6. Add to n8n Stripe credential

### Step 4: Update Email Templates

Update Day 8 and Day 10 emails with your actual Stripe payment link:
```
https://buy.stripe.com/XXXXXXX?prefilled_email={{email}}
```

---

## 7. Analytics & Reporting Setup

### Step 1: Create Google Sheet Dashboard

1. Create new Google Sheet: "Sales Dashboard"
2. Create sheet named "Dashboard"
3. Add headers in Row 1:
   - A1: Date
   - B1: Total Leads
   - C1: Today Leads
   - D1: Today Orders
   - E1: Today Revenue
   - F1: Avg Order Value
   - G1: Conversion Rate
   - H1: Top Sources

4. Add formulas for charts/summaries:
   - Create pivot tables
   - Add charts for visualization
   - Set up conditional formatting

### Step 2: Configure n8n Analytics Workflow

1. Open workflow: `04-analytics-reporting.json`
2. Update Google Sheet ID:
   - Get from Sheet URL: `docs.google.com/spreadsheets/d/[SHEET_ID]/edit`
3. Customize Slack message format
4. Set schedule (default: daily at 9 AM)
5. Activate workflow

### Step 3: Set Up Dashboard Sharing

1. Make Google Sheet viewable by your team
2. Create dashboard link
3. Optional: Embed in internal website
4. Create mobile bookmarks for quick access

---

## 8. Testing & Launch

### Pre-Launch Checklist

- [ ] All n8n workflows activated
- [ ] Webhook URLs configured correctly
- [ ] Airtable tables created with correct fields
- [ ] SendGrid verified and tested
- [ ] Landing page deployed and accessible
- [ ] Stripe products created
- [ ] Stripe webhook configured
- [ ] Google Analytics tracking installed
- [ ] All email templates customized
- [ ] Unsubscribe links working

### Testing Process

#### Test 1: Lead Capture Flow
1. Submit test form on landing page
2. Check n8n execution logs
3. Verify lead appears in Airtable
4. Confirm welcome email received
5. Check Slack notification sent

#### Test 2: Email Sequence
1. Create test lead with old creation date
2. Manually trigger nurture workflow
3. Verify correct email sent
4. Check "Last Contact" updated in Airtable
5. Test all 5 emails in sequence

#### Test 3: Payment Flow
1. Use Stripe test mode
2. Complete test purchase using test card: `4242 4242 4242 4242`
3. Verify webhook received in n8n
4. Check order created in Airtable
5. Verify lead status updated to "customer"
6. Confirm confirmation and onboarding emails sent
7. Check Slack notification

#### Test 4: Analytics
1. Wait for scheduled run or trigger manually
2. Check Google Sheet updated
3. Verify Slack report sent
4. Confirm metrics are accurate

### Launch Steps

1. **Switch Stripe to Live Mode:**
   - Update credentials in n8n
   - Update webhook endpoints
   - Test one real transaction

2. **Update Landing Page:**
   - Remove test banners
   - Final content review
   - Check mobile responsiveness

3. **Drive Traffic:**
   - Launch ad campaigns with UTM tracking
   - Share on social media
   - Send to email list
   - Test with small budget first

4. **Monitor First Week:**
   - Check workflows daily
   - Review error logs
   - Optimize lead scoring
   - Adjust email timing based on engagement

---

## 9. Ongoing Optimization

### Weekly Tasks

- **Monday:**
  - Review weekend performance
  - Check for workflow errors
  - Respond to any stuck leads

- **Wednesday:**
  - Analyze email open/click rates
  - A/B test subject lines
  - Review lead quality by source

- **Friday:**
  - Weekly revenue review
  - Update landing page copy if needed
  - Plan next week's improvements

### Monthly Tasks

- Analyze full funnel conversion rates
- Update email sequences based on data
- Add new lead sources
- Create case studies from successful customers
- Review and optimize ad spend
- Update pricing/offers if needed

### Metrics to Track

| Metric | Goal | How to Improve |
|--------|------|----------------|
| Landing page conversion | 20-30% | Better copy, stronger CTA, simpler form |
| Email open rate | 20-30% | Better subject lines, send time optimization |
| Email click rate | 3-5% | More compelling CTAs, better content |
| Lead-to-customer conversion | 2-5% | Better qualification, stronger offer |
| Average order value | $500+ | Upsells, premium tiers, bundles |
| Customer lifetime value | $1000+ | Retention campaigns, recurring revenue |

### Common Issues & Solutions

**Issue:** Leads not appearing in Airtable
**Solution:** Check webhook URL, verify Airtable credentials, check workflow execution logs

**Issue:** Emails not sending
**Solution:** Verify SendGrid API key, check sender verification, review email content for spam triggers

**Issue:** Stripe webhook not firing
**Solution:** Verify webhook URL, check signing secret, ensure workflow is activated

**Issue:** Low conversion rate
**Solution:** Improve landing page copy, adjust lead magnet, simplify form, test different offers

**Issue:** High unsubscribe rate
**Solution:** Reduce email frequency, improve content value, better segmentation

---

## Advanced Features (Optional)

### SMS Notifications
- Add Twilio integration
- Send SMS for high-value leads
- SMS reminders for abandoned carts

### Chatbot Integration
- Add ManyChat or Chatfuel
- Automated FAQ responses
- Lead qualification via chat

### Calendar Booking
- Integrate Calendly
- Auto-schedule demos for hot leads
- Confirmation and reminder emails

### Advanced Lead Scoring
- Add more data points
- Machine learning prediction
- Behavior-based scoring

### Retargeting
- Facebook Pixel installation
- Google Ads remarketing
- Custom audience creation

---

## Support & Resources

### Documentation
- n8n Docs: https://docs.n8n.io
- Airtable Support: https://support.airtable.com
- Stripe Docs: https://stripe.com/docs
- SendGrid Docs: https://docs.sendgrid.com

### Community
- n8n Community: https://community.n8n.io
- r/n8n: https://reddit.com/r/n8n
- IndieHackers: https://indiehackers.com

### Troubleshooting
- Check n8n execution logs for errors
- Verify all API credentials
- Test webhooks with tools like webhook.site
- Review workflow connections and data mapping

---

## Cost Breakdown

| Service | Plan | Monthly Cost |
|---------|------|--------------|
| n8n Cloud | Starter | $20 |
| Airtable | Free | $0 |
| SendGrid | Free | $0 |
| Stripe | Pay as you go | 2.9% + $0.30/transaction |
| Domain | Annual | ~$1/month |
| Hosting (Vercel) | Free | $0 |
| **Total** | | **~$21/month + transaction fees** |

### ROI Calculation

If you generate:
- 100 leads/month (landing page + ads)
- 3% conversion rate = 3 customers
- Average order value = $500
- Monthly revenue = $1,500
- Cost = $21 + ad spend
- **Net profit: $1,479+ per month**

---

## Next Steps

1. ✅ Complete all account setups
2. ✅ Configure Airtable CRM
3. ✅ Import and configure n8n workflows
4. ✅ Deploy landing page
5. ✅ Set up payment processing
6. ✅ Test entire funnel
7. ✅ Launch and drive traffic
8. ✅ Monitor and optimize

**Questions?** Review the troubleshooting section or check the documentation links above.

**Ready to scale?** Once you're consistently generating sales, consider:
- Hiring virtual assistants for manual tasks
- Upgrading to paid plans for more capacity
- Adding more lead sources and funnels
- Building out additional products
- Creating affiliate/referral programs

---

Good luck with your autonomous sales system! 🚀
